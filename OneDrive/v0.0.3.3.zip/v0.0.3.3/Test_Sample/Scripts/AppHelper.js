﻿String.prototype.format = function (args) {
    var str = this;
    return str.replace(String.prototype.format.regex, function (item) {
        var intVal = parseInt(item.substring(1, item.length - 1));
        var replace;
        if (intVal >= 0) {
            replace = args[intVal];
        } else if (intVal === -1) {
            replace = "{";
        } else if (intVal === -2) {
            replace = "}";
        } else {
            replace = "";
        }
        return replace;
    });
};
String.prototype.format.regex = new RegExp("{-?[0-9]+}", "g");
function DoTest() {
    var inputData = "{ 'input': '{0}'}";
    inputData = inputData.format(["Bijay"]);
    //$.blockUI({ message: '<img src=\"images/Waiting_1.gif\" align=\"middle\" /> Please wait, we are processing your request...' });
    $.ajax({
        url: 'https://localhost:12030/service/GetDatas',
        data: '=' + 'Bijay',
        //data: JSON.stringify(inputData),
        //contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            //$(document).ajaxStop($.unblockUI);
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            //$(document).ajaxStop($.unblockUI);
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function DoScan() {
    //$.blockUI({ message: '<img src=\"images/Waiting_1.gif\" align=\"middle\" /> Please wait, we are processing your request...' });
    $.ajax({
        url: 'https://localhost:12030/service/GetScanQrCodeData',
        dataType: 'text',
        type: 'GET',
        cache: false,
        timeout: 120000,

        success: function (data) {
            //$(document).ajaxStop($.unblockUI);
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            //$(document).ajaxStop($.unblockUI);
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function DoIFISFPCapture() {
    $.ajax({
        url: 'https://localhost:12030/service/CaptureFingerPrintIFIS',
        dataType: 'json',
        type: 'GET',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function CheckIfPinpadConnected() {
    //$.blockUI({ message: '<img src=\"images/Waiting_1.gif\" align=\"middle\" /> Please wait, we are processing your request...' });
    $.ajax({
        url: 'https://localhost:12030/service/IsPinpadDeviceConnected',
        dataType: 'text',
        type: 'GET',
        cache: false,
        timeout: 120000,

        success: function (data) {
            //$(document).ajaxStop($.unblockUI);
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            //$(document).ajaxStop($.unblockUI);
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
/*function DoSwipeCard() {
    //$.blockUI({ message: '<img src=\"images/Waiting_1.gif\" align=\"middle\" /> Please wait, we are processing your request...' });
    $.ajax({
        url: 'https://localhost:12030/service/GetSwipeCardData',
        dataType: 'text',
        type: 'GET',
        cache: false,
        timeout: 120000,

        success: function (data) {
            //$(document).ajaxStop($.unblockUI);
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            //$(document).ajaxStop($.unblockUI);
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}*/
function DoSwipeCard() {
    //$.blockUI({ message: '<img src=\"images/Waiting_1.gif\" align=\"middle\" /> Please wait, we are processing your request...' });
    $.ajax({
        url: 'https://localhost:12030/service/GetSwipeCardData',
        dataType: 'text',
        type: 'GET',
        cache: false,
        timeout: 120000,

        success: function (data) {
            //$(document).ajaxStop($.unblockUI);
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            //$(document).ajaxStop($.unblockUI);
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function DoSwipeCardEMV() {
    $.ajax({
        url: 'https://localhost:12030/service/GetSwipeCardDataEMV',
        data: '=' + '200',
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function GetPinBlockData() {
    var obj = { 'swipeDeviceType': '1', 'track2Data': 'lwzcznlzcbbczmxbccxkpxxc' };
    $.ajax({
        url: 'https://localhost:12030/service/GetPinBlockData',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function GetOtpBlockData() {
    var obj = { 'swipeDeviceType': '1', 'track2Data': '6521602789240595=22022264339999999999', 'otpLength': '4' };
    $.ajax({
        url: 'https://localhost:12030/service/GetOtpBlockData',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function InjectTpkTdk() {
    var obj = { 'swipeDeviceType': '1', 'tpk': 'lwzcznlzcbbczmxbccxkpxxc', 'tdk': '123lwzczsdfsdffsdfnlzcbbczmxbccxkpxxc' };
    $.ajax({
        url: 'https://localhost:12030/service/InjectTpkTdk',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function InjectTmk() {
    var obj = { 'swipeDeviceType': '1', 'tmk': 'lwzcznlzcbbczmxbccxkpxxc' };
    $.ajax({
        url: 'https://localhost:12030/service/InjectTmk',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function InjectDtmk() {
    var obj = { 'swipeDeviceType': '2', 'tmk': 'lwzcznlzcbbczmxbccxkpxxc' };
    $.ajax({
        url: 'https://localhost:12030/service/InjectDtmk',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function OpenPassbookPrinter() {
    $.ajax({
        url: 'https://localhost:12030/service/OpenPassbookPrinter',
        dataType: 'text',
        type: 'GET',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function EjectPassBook() {
    $.ajax({
        url: 'https://localhost:12030/service/EjectPassBook',
        dataType: 'text',
        type: 'GET',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function CheckPaperStatus() {
    $.ajax({
        url: 'https://localhost:12030/service/CheckPaperStatus',
        dataType: 'text',
        type: 'GET',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function PrintPassbook() {
    //var obj = { 'printData': '  02-03-2019    538996    ASCO MOTORS /AS                                 2356.00                             7760.00    ', 'font': 10, 'cpi': 11, 'lpi': 11, 'linesPrinted': 12 };
    var obj = { 'printData': '  20170719              SMS CHRG FOR:01-04-2017to30-06-2017               17.70                        386.51_  20170723              QAB Charges from 01-04-2017 to 30-06-2017        141.60                        244.91_  20170816              IOC Ref No3000053270                                           45.65           290.56_  20171107              TRTR/OFADPAY/803113005330/FIC                                 588.00           878.56_  20171107              TRTR/OFADPAY/803113005334/FIC                                 250.00          1128.56_  20171107              TRTR/OFADPAY/803113005336/FIC                                 583.00          1711.56_  20171107              TRTR/OFADPAY/803214005398/FIC                                 200.00          1911.56_  20171107              TRTR/OFADPAY/803214005399/FIC                                 205.00          2116.56_  20180702              TRTR/842011000044/12-11-2019 11:28:10/FIK                      10.00          2126.56_  20180702              TRTR/842011000045/12-11-2019 11:28:10/FIK                      10.00          2136.56_', 'font': 10, 'cpi': 11, 'lpi': 11, 'linesPrinted': 21, 'secondPageheaderSpaceReqd': '0', 'isPageBreakAtThirty': '0', 'maxLinesPassbookCanPrint': 34, 'firstPageVerticalStartIndex': 7 };
    $.ajax({
        url: 'https://localhost:12030/service/PrintPassbook',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
//===============================================
function DoSetData() {
    var obj = { 'Key': 'Bijay\\30.txt', 'Value': 'This is a test sample. bijay 1' };
    $.ajax({
        url: 'https://localhost:12030/service/SetData',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function StoreElog() {
    var obj = { 'Dir': 'eLog', 'FileName': 'test.txt', 'FileData': 'This is a test sample. bijay 1' };
    $.ajax({
        url: 'https://localhost:12030/service/eLog',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function DeleteElog() {
    var obj = { 'Dir': 'eLog', 'FileName': 'test.txt', 'FileData': '' };
    $.ajax({
        url: 'https://localhost:12030/service/DeleteElog',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function DoGetData() {
    $.ajax({
        url: 'https://localhost:12030/service/GetData',
        data: '=' + '30',
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function DoDeleteKeys() {
    $.ajax({
        url: 'https://localhost:12030/service/DeleteKeys',
        data: '=' + '1|30',
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function GetUniqueDeviceID() {
    $.ajax({
        url: 'https://localhost:12030/service/GetUniqueDeviceID',
        //url: 'http://localhost:8100/service/GetUniqueDeviceID',
        dataType: 'text',
        type: 'GET',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function GetAppVersion() {
    $.ajax({
        url: 'https://localhost:12030/service/GetAppVersion',
        dataType: 'text',
        type: 'GET',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function StoreEncrGUID() {
    $.ajax({
        url: 'https://localhost:12030/service/StoreFIStackID',
        data: '=' + '1111000011110000',
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function GetGUID() {
    $.ajax({
        url: 'https://localhost:12030/service/GetFIStackID',
        //url: 'http://localhost:8100/service/GetUniqueDeviceID',
        dataType: 'text',
        type: 'GET',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
/*function printPBData()
{
    var data = '20170719        SMS CHRG FOR:01-04-2017to30-06-2017               D        17.70       386.5120170723        QAB Charges from 01-04-2017 to 30-06-2017         D       141.60       244.9120170816        IOC Ref No3000053270                              C        45.65       290.5620171107        TRTR/OFADPAY/803113005330/FIC                     C       588.00       878.5620171107        TRTR/OFADPAY/803113005334/FIC                     C       250.00      1128.5620171107        TRTR/OFADPAY/803113005336/FIC                     C       583.00      1711.5620171107        TRTR/OFADPAY/803214005398/FIC                     C       200.00      1911.5620171107        TRTR/OFADPAY/803214005399/FIC                     C       205.00      2116.5620180702        TRTR/842011000044/12-11-2019 11:28:10/FIK         C        10.00      2126.5620180702        TRTR/842011000045/12-11-2019 11:28:10/FIK         C        10.00      2136.56';

    var printData = [];
	var objJSON = {};
    var startIndex = 0;
    var endIndex = 0;
    var counter = 93;
    for (var i = 0; i < (data.length)/93; i++) {
		objJSON.date = data.substring(startIndex + 0, endIndex + 8);
        objJSON.cheque = data.substring(startIndex + 8, endIndex + 16);
        objJSON.desc = data.substring(startIndex + 16, endIndex + 66);
        objJSON.type = data.substring(startIndex + 66, endIndex + 67);
        objJSON.amnt = data.substring(startIndex + 67, endIndex + 80);
        objJSON.balance = data.substring(startIndex + 80, endIndex + 93);
		printData[i] = objJSON;

		startIndex = startIndex + counter;
        endIndex = endIndex + counter;
    }
	for
    console.log(JSON.stringify(printData));
    alert(JSON.stringify(printData));
}*/
function printPBData() {
    var data = '20170719        SMS CHRG FOR:01-04-2017to30-06-2017               D        17.70       386.5120170723        QAB Charges from 01-04-2017 to 30-06-2017         D       141.60       244.9120170816        IOC Ref No3000053270                              C        45.65       290.5620171107        TRTR/OFADPAY/803113005330/FIC                     C       588.00       878.5620171107        TRTR/OFADPAY/803113005334/FIC                     C       250.00      1128.5620171107        TRTR/OFADPAY/803113005336/FIC                     C       583.00      1711.5620171107        TRTR/OFADPAY/803214005398/FIC                     C       200.00      1911.5620171107        TRTR/OFADPAY/803214005399/FIC                     C       205.00      2116.5620180702        TRTR/842011000044/12-11-2019 11:28:10/FIK         C        10.00      2126.5620180702        TRTR/842011000045/12-11-2019 11:28:10/FIK         C        10.00      2136.56';

    var printData = [];
    var objJSON = {};
    var startIndex = 0;
    var endIndex = 0;
    var counter = 93;
    for (var i = 0; i < (data.length) / 93; i++) {
        objJSON.date = data.substring(startIndex + 0, endIndex + 8);
        objJSON.cheque = data.substring(startIndex + 8, endIndex + 16);
        objJSON.desc = data.substring(startIndex + 16, endIndex + 57);
        objJSON.type = data.substring(startIndex + 66, endIndex + 67);
        objJSON.amnt = data.substring(startIndex + 67, endIndex + 80);
        objJSON.balance = data.substring(startIndex + 80, endIndex + 93);
        printData[i] = objJSON;
        objJSON = {};
        startIndex = startIndex + counter;
        endIndex = endIndex + counter;
    }
    var output;
    for (var i = 0; i < printData.length; i++) {
        if (printData[i].type == "C") {
            if (output == null) {
                output = '  ' + printData[i].date + '     ' + printData[i].cheque + ' ' + printData[i].desc + '              ' + printData[i].amnt + '    ' + printData[i].balance + '_';
            }
            else {
                output = output + '  ' + printData[i].date + '     ' + printData[i].cheque + ' ' + printData[i].desc + '              ' + printData[i].amnt + '    ' + printData[i].balance + '_';
            }
        }
        else {
            if (output == null) {
                output = '  ' + printData[i].date + '     ' + printData[i].cheque + ' ' + printData[i].desc + ' ' + printData[i].amnt + '                 ' + printData[i].balance + '_';
            }
            else {
                output = output + '  ' + printData[i].date + '     ' + printData[i].cheque + ' ' + printData[i].desc + ' ' + printData[i].amnt + '                 ' + printData[i].balance + '_';
            }
        }
    }
    //console.log(JSON.stringify(printData));
    //alert(JSON.stringify(printData));
    alert(output);
}
var comPort;
function GetPOSPrinterComPortByDevice() {
    $.ajax({
        url: 'https://localhost:12030/service/GetPOSPrinterComPortByDevice',
        data: '=' + '1',
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
                comPort = data;
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function PrintImageInDapperprinter() {
    $.ajax({
        url: 'https://localhost:12030/service/PrintImageInDapperprinter',
        data: '=' + '1',
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function PrintInputImageInPOSPrinter() {
    var obj = { 'textToPrint': 'Qk22XwAAAAAAADYEAAAoAAAAgAEAAD0AAAABAAgAAAAAAAAAAAASCwAAEgsAAAAAAAAAAAAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgH9/f39/f39/f39/f39/f39/f39/f39/f39/f3+AgICAgICAgICAgICAgICAgICAgICAgICAgICAUFiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFROUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJWXGBkbXh+gICAgICAgICAgICAgICAgICAgICAUFiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAf4CAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTExMTExMTExMTExMTExMTExLSUpKSktQYnOAgICAgICAgICAgICAgICAgICAUFiAgICAgICAgHhJRklJSUlJSUlJSUhIUWN8gICAgICAgFRBSUdGdoCAf09ESUlJSUlJSUlJSUlJSUhCbIB6SkVJSUlJSUlJSUlJSUlJSEJsgIBUQklETn6AgICAgICAgICAgGg+SklAVYCAgICAgICAgICAgFNCSUo8ZICAgICAW0BJSEJsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExLSElRboCAgICAgICAgICAgICAgICAUFiAgICAgICAgHIiIiIiIiIiIiIiIiIiISIiU4CAgICAgDQeIiIibICAfioiIiIiIiIiIiIiIiIiIiIiXIB2IyAiIiIiIiIiIiIiIiIiIiJegIAyIiIiKXyAgICAgICAgICAgG4hIiIiIXSAgICAgICAgICAciIiIiIhZYCAgICAQCAiIiJegICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExKSlF2gICAgICAgICAgICAgICAUFiAgICAgICAgHQiIiIiIiIiIiIiIiIiIiIiITWAgICAgDUeIiIiboCAgC0iIiIiIiIiIiIiIiIiIiIiXoB4JCAiIiIiIiIiIiIiIiIiIiJfgIA0IiIiKn2AgICAgICAgICAgIBAISIiIVyAgICAgICAgICAViAiIiIygICAgICAQiAiIiJfgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTEpKZICAgICAgICAgICAgICAUFiAgICAgICAgHQiIiIjHh4jIiIiJBwYHiMiIh9GgICAgDUeIiIiboCAgC0iIiIiICAgICAgICAgICAgXIB4JCAiIiIgICAgICAgICAgICBdgIA0IiIiKn2AgICAgICAgICAgIBgICIiIjqAgICAgICAgICAOyAiIiBSgICAgICAQiAiIiJfgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTE1MRmWAgICAgICAgICAgICAUFiAgICAgICAgHQiIiIgNFhSVFRUU1xQJBwjIiIgZoCAgDUeIiIiboCAgC0iIiIkRkpGR0dHR0dHR0Y/a4B3JCAiIiVGSkZHR0dHR0dHRj9sgIA0IiIiKn2AgICAgICAgICAgIB7KCIiIiJwgICAgICAgIB0IiIiIiFwgICAgICAQiAiIiJfgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTURogICAgICAgICAgICAUFiAgICAgICAgHQiIiIYTICAgICAgICAey4dIiIgRICAgDUeIiIiboCAgC0iIiIpfoCAgICAgICAgICAgIB3JCAiIip+gICAgICAgICAgICAgIA0IiIiKn2AgICAgICAgICAgICASCAiIiI8UElJSUlJSk88IiIiIDqAgICAgICAQiAiIiJfgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTUxGdICAgICAgICAgICAUFiAgICAgICAgHQiIiIYRICAgICAgICAgHQcICIhMICAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiKn2AgICAgICAgICAgICAZiAiIiIiIiIiIiIiIiIiIiIiIFqAgICAgICAQiAiIiJfgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTklERUVFRUVFRUVFRUVFSEpKTExMTExMTExMTExMTE1JUX6AgICAgICAgICAUFiAgICAgICAgHQiIiIZRICAgICAgICAgH0rICIiKHuAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiKn2AgICAgICAgICAgICAfi4hIiIiIiIiIiIiIiIiIiIiJHaAgICAgICAQiAiIiJfgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMSWZ1cHBwcHBwcHBwcHBwbGFbUElKTExMTExMTExMTExNRmyAgICAgICAgICAUFiAgICAgICAgHQiIiIZRICAgICAgICAgH4qHyIiK36AgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiKn6AgICAgICAgICAgICAgEsgIiIjIB4jIiIiHiAjIiIgQICAgICAgICAQiAiIiJggICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMSHKAgICAgICAgICAgICAgICAfnRXSUxNTExMTExMTExMSFaAgICAgICAgICAUFiAgICAgICAgHQiIiIYRoCAgICAgICAgHQaICIhOoCAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiJD5APj4+Pj5GWXiAgICAgGwiIiIfNFpQVFRQWjQgIiIgXoCAgICAgICAPiAiIiJegICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTG6AgICAgICAgICAgICAgICAgICAZ0dMTExMTExMTExMTEh2gICAgICAgICAUFiAgICAgICAgHQiIiIZRoCAgICAgIB+ZCUeIiIhWICAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiIiIiIiIiIiIhISJOgICAgIA0ICIeLHyAgICAfS0eIiEoeYCAgICAgIBsICIiIiA5gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAgGlGTUxMTExMTExMTEhsgICAgICAgICAUFiAgICAgICAgHQiIiIhJzg6OTk5OzUmGh0kIiA4gICAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiIiIiIiIiIiIiIiIgOoCAgIBUICIiE2uAgICAbBQiIiBEgICAgICAgIA7ICIiIiIgYoCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAgH5QSkxMTExMTExMTEhigICAgICAgICAUFiAgICAgICAgHQiIiIjIBwcHBwcHB4gIiIiIjx7gICAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiIiIhISEiHRsgIiIiIFKAgIByIiIiGESAgICAShYiIiFigICAgICAgGIeIiIiIiIiMoCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAgIBsR0xMTExMTExMTExYgICAgICAgICAUFiAgICAgICAgHQiIiIiIiAgICAgICIiIiIiSICAgICAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiJmFoY2NkaFQcHyMiIix/gICAOiIiHx57gIB6JCAiIC5+gICAgICAgDEgIiIgISIiH1yAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAgIBwS0xMTExMTExMTEpYgICAgICAgICAUFiAgICAgICAgHQiIiIjIB4kIyMjJCIaHCIiIU6AgICAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiKn6AgICAgIBwICAiIiJpgICAWCAiIhRogIBpGCIiIEyAgICAgICAWiAiIiBNQyEiIS1+gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAgIBzS0xMTExMTExMTEdagICAgICAgICAUFiAgICAgICAgHQiIiIcQHhycnJycnBqORwjIiFYgICAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiKn2AgICAgICASBkiIiFegICAdiMiIhZGgIBNFyIiImqAgICAgIB7KSEiISJ+ZyAiIh5UgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAgIB0S0xMTExMTExMTEtYgICAgICAgICAUFiAgICAgICAgHQiIiIYSoCAgICAgICAfzccIiIugICAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiKn2AgICAgICAVBwiIiJVgICAgEIgIh8ffoAmHiIhMoCAgICAgIBQICIiIEaAgC8hIiAoeICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAgIBySkxMTExMTExMTEpcgICAgICAgICAUFiAgICAgICAgHQiIiIZRICAgICAgICAgF4ZIiIib4CAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiKn2AgICAgICAVB0iIiJUgICAgGQgIiIYcHcbIiIiUICAgICAgHQiICIiIG2AgFUfIiIfToCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAgIBuR0xMTExMTExMTEhogICAgICAgICAUFiAgICAgICAgHQiIiIZRICAgICAgICAgF4YIiIiaoCAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiK3yAgICAgICASxkiIiBegICAgIAyISIcT1IcIiIibYCAgICAgEYeIiIgQoCAgHoqISIgJHSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAgIBYSExMTExMTExMTEdzgICAgICAgICAUFiAgICAgICAgHQiIiIYSYCAgICAgICAfDAcIiIicICAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiJn6AgICAgIByHiAiIiJqgICAgIBIICIiIyQhIiE2gICAgICAbB8iIiIga4CAgIBOHyIiIEeAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAgHJFTUxMTExMTExMS0x9gICAgICAgICAUFiAgICAgICAgHQiIiIcOWxoaGdoZVxWJBwkIiIwgICAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIhJWZuaGhpY04eHiMiIDGAgICAgIBqIiIiICAiIiBVgICAgICAPCAiIiE+gICAgIB0IyIiIiBvgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAfE5JTUxMTExMTExNRmKAgICAgICAgICAUFiAgICAgICAgHQiIiIjIBweHh4eIB4ZICIiIiBSgICAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiIyEeHh4fHhogIyIiHlqAgICAgICAMyAiIiIiISJzgICAgIBiHyIiIiFngICAgICARiAiIiFBgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgIBwSkhOTExMTExMTExMRniAgICAgICAgICAUFiAgICAgICAgHQiIiIiIiEhISEhIiIiIiIiIDiAgICAgDUeIiIiboCAgC0iIiIqfYCAgICAgICAgICAgIB3JCAiIip9gICAgICAgICAgICAgIA0IiIiIiEhISEhIiIiIiEgQ4CAgICAgICATCAiIiIiIDyAgICAgIA0ICIiIDqAgICAgICAbiIiIiIeaoCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTG2Ae3t7e3t7e3t7e3t7enp2alJJSk5MTExMTExMTE5FYICAgICAgICAgICAUFiAgICAgICAgHMiIiIiIiIiIiIiIiIhIiIiRn+AgICAgDQeIiIiboCAfiwiIiIpfICAgICAgICAgICAgIB2JCAiIil8gICAgICAgICAgICAgIAzIiIiIiIiIiIiIiEiISJVgICAgICAgICAbiIhIiIiIV2AgICAgFIgIiIiIGSAgICAgICAgDwgIiIgNICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTE5OTk5OTk5OTk5OTk5OTExKSUtMTExMTExMTExMTUpJfYCAgICAgICAgICAUFiAgICAgICAgHY0MDQ0NDQ0NDQ0NDI5RFRygICAgICAgEMoNDAwcoCAfzwsNC46foCAgICAgICAgICAgIB4NS40Ljp+gICAgICAgICAgICAgIBCKjQ0NDQ0NDQ0MjhEW3qAgICAgICAgICAgEIqNDQuNHiAgICAgDgpNDQqQoCAgICAgICAgGoqMjQyKGqAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExNSkZ2gICAgICAgICAgICAUFiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAfXyAgICAgICAgICAgICAgICAgICAfnyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTE1KSG6AgICAgICAgICAgICAUFiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExNTEhQeICAgICAgICAgICAgICAUFiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExJS2B+gICAgICAgICAgICAgICAUFiAgICAgICAgHxmZWZmZmZmZmZmZmZqcX+AgICAgICAfGZlZmZkeoCAgICAgICAgG5iZmZidIBqYGZmYnSAgICAgICAgICAgIB2ZGZmZWN+fmRmZmRofoCAgICAgICAgHRiZmZgcXRgZmZjbICAgICAgICAgICAgHxmZWZnYHSAgIBuYmZmYnSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExKSExceoCAgICAgICAgICAgICAgICAUFiAgICAgICAgHIgICAgICAgICAgIB8hIik+aICAgICAciAgICAgaoCAgICAgICAgDwfICAgUoBSHiAgHjqAgICAgICAgICAgIBMHiAgHjKAcB8gICAnfICAgICAgICAgEgdICAeYXQeICAeJnmAgICAgICAgICAgGMfICAfIHGAgIA+HiAgIFKAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTUxLS0tLS0tLS0tLS0tLTExMSklKS0tVbHyAgICAgICAgICAgICAgICAgICAUFiAgICAgICAgHQiIiIiIiIiIiIiIiIiIiIiIjp8gICAdCIiIiIibYCAgICAgICAgD4iIiIiU4B8KSEiISJygICAgICAgICAgH4uICIiH1iAbSIiIiIqfYCAgICAgICAgDYhIiEicoAzICIiIF6AgICAgICAgICAgEUgIiIgQoCAgIBAICIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTE5MTExMTExMTExMTExMTE1OV2BkcH6AgIB9bmR8gICAgICAgICAgICAgICAUFiAgICAgICAgHQiIiIiIxwYGhoaGRwgISIiIiAxfYCAdCIiIiIiboCAgICAgICAgD4iIiIiVICAQyEiIiFUgICAgICAgICAgGggIiIiInSAbSIiIiIqfYCAgICAgICAfiwiIiIpfIBYICIiH0GAgICAgICAgICAeyoiIiIgY4CAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMSW5+e3t7e3t7e3t7e3t8e3p9gICAgIB+dGhgXl5gfoCAgICAgICAgICAgICAUFiAgICAgICAgHQiIiIiIDZCPz8/QTwpHBwkIiIfSoCAcyIiIiIiboCAgICAgICAgD4iIiIiVICAZiIiIiA0gICAgICAgICAgEkgIiIgQoCAbSIiIiIqfYCAgICAgICAeCYiIiAvgIB2IyIiIiR2gICAgICAgICAYiAiIiItf4CAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMS3CAgICAgICAgICAgICAgICAgHxxcGdgX2BgYGFdYn+AgICAgICAgICAgICAUFiAgICAgICAgHQiIiIhHHKAgICAgICAbiocIyIiJHiAdCIiIiIiboCAgICAgICAgD4iIiIiVICAgDQhIiIgbICAgICAgICAfiwiIiIgZICAbSIiIiIqfYCAgICAgICAciIiIiI0gICAQiEiIiBagICAgICAgICARR4iIiBNgICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgH5iXGBgYGBgYGBhXHCAgICAgICAgICAgICAUFiAgICAgICAgHQiIiIhHHGAgICAgICAgHsgHiIiImGAdCIiIiIiboCAgICAgICAgD4iIiIiVICAgE4gIiIhLjs3Nzc3Nzc6NCIiIiEsfoCAbSIiIiIqfYCAgICAgICAbCIiIiI0gICAYyEiIiEqOjg3Nzc3Nzg2JCIiIiFugICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgIB7XGBgYGBgYGBgYF98gICAgICAgICAgICAUFiAgICAgICAgHQiIiIhHHCAgICAgICAgIA6HCIiH16AdCIiIiIiboCAgICAgICAgD4iIiIiVICAgG4gIiIiIiAgICAgICAgISIiIiBKgICAbiIiIiIqfYCAgICAgICAWCAiIiA/gICAfi4iIiIhICAgICAgICAgIiIiITeAgICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAZl5gYGBgYGBgYV1ygICAgICAgICAgICAUFiAgICAgICAgHQiIiIhHHCAgICAgICAgIA8HiIiIF6AdCIiIiIiboCAgICAgICAgD4iIiIiVICAgIA5ISIiIiIfHx8fHx4hIiIiIiBsgICAbiIiIiIqfYCAgICAgICAOSAiIiBUgICAgE4gIiIiIiAeHx8fHiAiIiIiIViAgICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAbl5gYGBgYGBgYF9ogICAgICAgICAgICAUFiAgICAgICAgHQiIiIhGnKAgICAgICAgH4sHCIiImeAdCIiIiIiboCAgICAgICAgD4iIiIiVICAgIBcICIiIiYlHyAgICUnISIiIDiAgICAbiIiIiIqfoCAgICAgIBUIiIiIiBugICAgHIhIiIiJCQgICAgISQiIiIiJHaAgICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAclxgYGBgYGBgYGBkfoCAgICAgICAgICAUFiAgICAgICAgHQiIiIgHnSAgICAgICAgFsaIiIiLICAdCIiIiIiboCAgICAgICAgEAiIiIiVICAgIB4JSIiHiZ2fHh4enxAGiIiIFiAgICAbiIiIiIlQURCQkJCRC4hIiIiIEiAgICAgIA8ICIhGmp/eHh4gFgXIiIgQoCAgICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAcl1gYGBgYGBgYGBge4CAgICAgICAgICAUFiAgICAgICAgHQiIiIiJFJmXV5eXGVjNBgiIiIgXICAdCIiIiIiPEZCQkJCQkJCRiwiIiIiVICAgICARCAiIRhvgICAgHokHyIiInSAgICAbiIiIiIiIiIiIiIiIiIiIiIoVICAgICAgIBcISIiGFqAgICAgEIZIiIhY4CAgICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgICAbF5gYGBgYGBgYGBefICAgICAgICAgICAUFiAgICAgICAgHQiIiIiIhwgIiIiJB8bHiIiIR9NgICAdCIiIiIiIiIiIiIiIiIiIiIiIiIiVICAgICAZiAiIhhGgICAgGoXIiIgQYCAgICAbiIiIiIiIiIiIiIiICAiIiFCgICAgICAgIB+LCIiHSx+gICAdB0hIiItf4CAgICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgIB+YGBgYGBgYGBgYGBefICAgICAgICAgICAUFiAgICAgICAgHQiIiIiIiIiIiIiIiEiIiIiRG6AgICAdCIiIiIiIiIiIiIiIiIiIiIiIiIiVICAgICAgDAhIh4gfICAgEsWIiIgZICAgICAbiIiIiIiHCAiIiIiIh4cIiIhJnCAgICAgICARCAiIhtsgICAWhgiIiFNgICAgICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgIByXmBgYGBgYGBgYGBgeoCAgICAgICAgICAUFiAgICAgICAgHQiIiIiIhwgIyIjIBsaICMiVoCAgICAdCIiIiIiIiIiIiIiIiIiIiIiIiIiVICAgICAgFAgIiIXZYCAeBwgIiEsfoCAgICAbiIiIh8qbnpycnJyeHREGiIiICh4gICAgICAZiAiIhlKgICAOBoiIiFugICAgICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAgICAgICAgICAgICAgICAgHRdYGBgYGBgYGBgYGBjfoCAgICAgICAgICAUFiAgICAgICAgHQiIiIiJFpyaGhnbnBNGh8iIDJ+gICAdCIiIiIiOUI+Pj4+Pj4+QioiIiIiVICAgICAgHAiIiIaQICAaBgiIiBKgICAgICAbiIiIh4ofICAgICAgICAThgiIiBNgICAgICAgDAhIh0nfIByGyEiITeAgICAgICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTG6AgICAgICAgICAgICAgH54aV5gYGBgYGBgYGBgYGBmgICAgICAgICAgICAUFiAgICAgICAgHQiIiIgHXSAgICAgICAbBwgIh9IgICAdCIiIiIiboCAgICAgICAgD8iIiIiVICAgICAgIA8ICIgIHiAQRoiIiBsgICAgICAbiIiIh4keoCAgICAgICAcBshIiExgICAgICAgFAgIiIYZ4BVGCIiIViAgICAgICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAdGpubm5ubm5ubm5qZ2JfX2BgYGBgYGBgYGBgYF5vgICAgICAgICAgICAUFiAgICAgICAgHQiIiIhG3GAgICAgICAfi4eIiImeICAdCIiIiIiboCAgICAgICAgD4iIiIiVICAgICAgIBeICIiGGZ/HSAiIDiAgICAgICAbiIiIh4keoCAgICAgICAdCQgIiIjdoCAgICAgHAiIiIYT4AyHCIiJHaAgICAgICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHKAZ1xdXV1dXV1dXV1gYGBgYGBgYGBgYGBgYGBgYF15gICAgICAgICAgICAUFiAgICAgICAgHQiIiIhHHCAgICAgICAgDQeIiIgaoCAdCIiIiIiboCAgICAgICAgD4iIiIiVICAgICAgIB5JiIiGk5kGSIiIFiAgICAgICAbiIiIh4keoCAgICAgICAdB4gIiIiaoCAgICAgIA8ICIfNWQgIiIhQoCAgICAgICAgIBAISIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHGAa2BgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBhXmWAgICAgICAgICAgICAUFiAgICAgICAgHQiIiIhHHCAgICAgICAeiAeIiIgaICAdCIiIiIiboCAgICAgICAgD4iIiIiVICAgICAgICASCAiIiYmICIiInSAgICAgICAbiIiIh4keoCAgICAgICAXRgiIiEkdoCAgICAgIBeICIjIiIiIiIhY4CAgICAgICAgIBCICIiIlSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHGAa2BgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgXHqAgICAgICAgICAgICAUFiAgICAgICAgHQiIiIhGnGAgICAgIBwNB0iIiIicICAdCIiIiIiboCAgICAgICAgD4iIiIiVICAgICAgICAaiEiIiAgIyIgQYCAgICAgICAbiIiIh4ieoCAgICAgH9aHCEiIiE2gICAgICAgIB5JiIiIiAiIiItf4CAfW1sbm5ubnY7IiIiIkp6bm5ubmxugICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHGAa2BgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBccICAgICAgICAgICAgICAUFiAgICAgICAgHQiIiIiIDI8ODg4OC4cGyMiIiEwgICAdCIiIiIiboCAgICAgICAgD4iIiIiVICAgICAgICAgDIhIiIiIiIgZICAgICAgICAbiIiIiIiNjs4ODg6NigeICIiIiBagICAgICAgICASCAiIiIiIiFNgICAcyIiIiIiIiIiIiIiIiIiIiIiIiIngICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHGAa2BgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYF5ogICAgICAgICAgICAgICAUFiAgICAgICAgHQiIiIiIxwZGhoaGh4iIiIiIh5egICAdCIiIiIiboCAgICAgICAgD4iIiIiVICAgICAgICAgFIgIiIiIiEsfoCAgICAgICAbiIiIiIiHBoaGhoaHCAiIiIiITuAgICAgICAgICAaiEiIiIiIiFtgICAdCIiIiIiIiIiIiIiIiIiIiIiIiIngICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHGAa2BgYGBgYGBgYGBgYGBgYGBgYGBgYGBeXnKAgICAgICAgICAgICAgICAUFiAgICAgICAgHQiIiIiIiIiIiIiIiIiIiIgH1CAgICAdCIiIiIibYCAgICAgICAgD4iIiIiVICAgICAgICAgHMhISIiIiBKgICAgICAgICAbSIiIiIiIiIiIiIiIiIiIiEhOH6AgICAgICAgICAgDIgIiIiIDeAgICAdCIiIiIiIiIiIiIiIiIiIiIiIiImgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHGAa2BgYGBgYGBgYGBgYGBgYGBgYGBgXl9qfICAgICAgICAgICAgICAgICAUFiAgICAgICAgHMiIiIiIiIiIiIiIiIiIixCbICAgICAcyIiIiIibICAgICAgICAgD4iIiIiVICAgICAgICAgIBAICIiIiJsgICAgICAgICAbCIiIiIiIiIiIiIiIiIiIjJegICAgICAgICAgICAgFIgIiIiIViAgICAcyIiIiIiIiIiIiIiIiIiIiIiIiIngICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgFBMTExMTExMTExMTHCAamBgYGBgYGBgYGBgYGBfXl9eYGBmcXyAgICAgICAgICAgICAgICAgICAUFiAgICAgICAgHxsa2xsbGxsbGxsbGxwdoCAgICAgICAfGxrbGtqe4CAgICAgICAgHJpbGxodoCAgICAgICAgIB2aWxsam5/gICAgICAgICAe2prbGxsbGxsbGxsbGpueICAgICAgICAgICAgICAgHtqa2xsanqAgICAfGxrbGxsbGxsbGxsbGxsbGxsbGptgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgA==', 'comPort': ' comPort', 'printerDeviceType': '1' };
    $.ajax({
        url: 'https://localhost:12030/service/PrintInputImageInPOSPrinter',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function getDateTime_ddMMYYY() {
    var date = new Date();
    var curr_date = date.getDate();
    var curr_month = date.getMonth() + 1; //Months are zero based
    if (curr_date < 10) { curr_date = '0' + curr_date } if (curr_month < 10) { curr_month = '0' + curr_month }
    var curr_year = date.getFullYear();
    return curr_date + '-' + curr_month + '-' + curr_year;
}
function getDateTime_HHMMSS() {
    var date = new Date();
    var curr_hour = date.getHours();
    var curr_min = date.getMinutes();
    var curr_sec = date.getSeconds();
    if (curr_hour < 10) { curr_hour = '0' + curr_hour } if (curr_min < 10) { curr_min = '0' + curr_min } if (curr_sec < 10) { curr_sec = '0' + curr_sec }
    return curr_hour + ':' + curr_min + ':' + curr_sec;
}
function PrintLogoAndReceiptInPOSPrinter() {
    var getDate = getDateTime_ddMMYYY();
    var getDateTime = getDateTime_HHMMSS();
    var obj = { 'textToPrint': '        Deposit Receipt                                         Date:' + getDate + '    Time:' + getDateTime + 'Name: Venkatesh Murthy          TerminalID: 89012389423         Cust. Ac No.: 120020120212000145Cust. Name: Abhishek Chatterjee STAN: 129032                    RRN: 904845654629               Auth Code: 0924394034           Transaction Status: Success(00) Transaction Amount: Rs.200      Account Balance: Rs. 35200      --------------------------------\n', 'comPort': ' comPort', 'printerDeviceType': '1' };
    $.ajax({
        url: 'https://localhost:12030/service/PrintLogoAndReceiptInPOSPrinter',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function CompleteEMVTransaction() {
    var obj = { 'swipeDeviceType': '1', 'otherParams': '390100910A16BBB72F0A1CB1710014' };
    $.ajax({
        url: 'https://localhost:12030/service/CompleteEMVTransaction',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function GetPendingDataToPost() {
    $.ajax({
        url: 'https://localhost:12030/service/GetPendingDataToPost',
        dataType: 'json',
        type: 'GET',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
function GetOtpEncriptedData() {
    $.ajax({
        url: 'https://localhost:12030/service/GetOtpEncrData',
        data: '=' + '123456',
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
//Using SpeechSynthesizer

function Speak_1() {
    var obj = { 'textToSpeak': 'You are about to perform a withdrawal of rupees 2450', 'volume': 100, 'rate': 0 };
    $.ajax({
        url: 'https://localhost:12030/service/Speak',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
// Initializes a new instance of the StringBuilder class
// and appends the given value if supplied
function StringBuilder(value) {
    this.strings = new Array("");
    this.append(value);
}
// Appends the given value to the end of this instance.
StringBuilder.prototype.append = function (value) {
    if (value) {
        this.strings.push(value);
    }
}
// Clears the string buffer
StringBuilder.prototype.clear = function () {
    this.strings.length = 1;
}
// Converts this instance to a String.
StringBuilder.prototype.toString = function () {
    return this.strings.join("");
}
//Using local wav/mp3 files
//Response = 5,  Success
//Response = 2,  Unable to unmute audio
//Response = 4,  Unable to raise the volume to 100
//Response = 6,  Unable to play the audio

/*function Speak_2() {
    var dataToSpeak;
    var amt = '2431.10';
    var amtSplit = amt.split('.');
    dataToSpeak = new StringBuilder();
	dataToSpeak.append("AEPS.wav|WITHDRAW_AMT.WAV|");
    //dataToSpeak.append("AEPS.wav|WITHDRAW_AMT.WAV|3.WAV|SPACE.WAV|3.WAV|SPACE.WAV|3.WAV|SPACE.WAV|3.WAV|");
	//dataToSpeak.append("AEPS.wav|WITHDRAW_AMT.WAV|3.WAV|3.WAV|3.WAV|3.WAV|");
    if (amtSplit[0].length == 4) {
        dataToSpeak.append(amtSplit[0].charAt(0)); dataToSpeak.append('.wav'); dataToSpeak.append('|'); dataToSpeak.append('THOUSAND.wav'); dataToSpeak.append('|');
        dataToSpeak.append(amtSplit[0].charAt(1)); dataToSpeak.append('.wav'); dataToSpeak.append('|'); dataToSpeak.append('HUNDRED.wav'); dataToSpeak.append('|');
        dataToSpeak.append(amtSplit[0].charAt(2)); dataToSpeak.append(amtSplit[0].charAt(3)); dataToSpeak.append('.wav'); dataToSpeak.append('|'); dataToSpeak.append('RUPEES.wav');
    }
    if (amtSplit.length == 2) {
        dataToSpeak.append('|'); dataToSpeak.append(amtSplit[1].charAt(0)); dataToSpeak.append(amtSplit[1].charAt(1)); dataToSpeak.append('.wav'); dataToSpeak.append('|');
        dataToSpeak.append('PAISA.wav|PROCEED_AUTH.WAV|');
    }
    console.log(dataToSpeak.toString());
    var obj = { 'textToSpeak': dataToSpeak.toString(), 'lang': 'English' };
    $.ajax({
        url: 'https://localhost:12030/service/PlayKioskVoice',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}*/
function Speak_2() {
    var dataToSpeak;
    //var amt = '2431.10';
    //var amt = '24315910.19';
	var amt = '151150909';
    var amtSplit = amt.split('.');
    var amount = inWords(amtSplit[0]);
    //alert(amount);
    var amountSplit = amount.replace(/\s/g, '.wav|');
    //alert(amountSplit);
    dataToSpeak = new StringBuilder();
    dataToSpeak.append("AEPS.wav|WITHDRAW_AMT.WAV|");
    dataToSpeak.append(amountSplit);
    dataToSpeak.append('RUPEES.wav|');

    if (amtSplit.length == 2) {
        var paisa = inWords(amtSplit[1]);
        dataToSpeak.append(paisa.replace(/\s/g, '.wav|'));
        dataToSpeak.append('PAISA.wav|PROCEED_AUTH.WAV|');
    }
    console.log(dataToSpeak.toString());
    var obj = { 'textToSpeak': dataToSpeak.toString(), 'lang': 'English' };
    $.ajax({
        url: 'https://localhost:12030/service/PlayKioskVoice',
        data: JSON.stringify(obj),
        contentType: "application/json;charset=utf-8",
        dataType: 'json',
        type: 'POST',
        cache: false,
        timeout: 120000,

        success: function (data) {
            if (data == undefined) {
                alert("Error : 219");
            }
            else {
                alert(data);
            }
        },
        error: function (jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connected.\nPlease verify network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Session expired. Please refresh the page and try again.');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Unable to connect to the network.\nPlease check the connection and try again.');
            }
        }
    });
}
var a = ['', '1 ', '2 ', '3 ', '4 ', '5 ', '6 ', '7 ', '8 ', '9 ', '10 ', '11 ', '12 ', '13 ', '14 ', '15 ', '16 ', '17 ', '18 ', '19 '];
var b = ['', '', '20', '30', '40', '50', '60', '70', '80', '90'];

/*function inWords(num) {
    if ((num = num.toString()).length > 9) return 'overflow';
    n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n) return; var str = '';
    str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
    str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
    str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
    str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
    str += (n[5] != 0) ? ((str != '') ? '' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) : '';
	
	alert(n);
	alert(n[1]);
	alert(n[2]);
	alert(n[3]);
	alert(n[4]);
	alert(n[3][0]);
	alert(n[3][1]);
    return str;
}*/

function inWords(num) {
	if ((num = num.toString()).length > 9) return 'overflow';
    n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n) return; var str = '';
	
	if(Number(n[1]) > 20 ){
		const cr1 = Number((a[Number(n[1])] || b[n[1][0]])) + Number(a[n[1][1]]);
		str += (n[1] != 0) ? cr1 + ' crore ' : '';
	}
	else{
		const cr2 = Number((a[Number(n[1])] || b[n[1][0]]));
		str += (n[1] != 0) ? cr2 + ' crore ' : '';
	}
	
	if(Number(n[2]) > 20 ){
		const lk1 = Number((a[Number(n[2])] || b[n[2][0]])) + Number(a[n[2][1]]);
		str += (n[2] != 0) ? lk1 + ' lakh ' : '';
	}
	else{
		const lk2 = Number((a[Number(n[2])] || b[n[2][0]]));
		str += (n[2] != 0) ? lk2 + ' lakh ' : '';
	}
	if(Number(n[3]) > 20 ){
		const th1 = Number((a[Number(n[3])] || b[n[3][0]])) + Number(a[n[3][1]]);
		str += (n[3] != 0) ? th1 + ' thousand ' : '';
	}
	else{
		const th2 = Number((a[Number(n[3])] || b[n[3][0]]));
		str += (n[3] != 0) ? th2 + ' thousand ' : '';
	}
	
	str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
    str += (n[5] != 0) ? (Number(n[5]) + ' ') : '';
	return str;
}
